from .model import ImageClassifier


def load_model():
    return ImageClassifier()
